package com.vinteck.example.apiresponseprojection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiResponseProjectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
