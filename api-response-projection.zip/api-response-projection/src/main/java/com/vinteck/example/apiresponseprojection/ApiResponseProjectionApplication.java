package com.vinteck.example.apiresponseprojection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiResponseProjectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiResponseProjectionApplication.class, args);
	}

}
