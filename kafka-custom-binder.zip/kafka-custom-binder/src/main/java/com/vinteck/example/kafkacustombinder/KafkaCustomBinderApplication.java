package com.vinteck.example.kafkacustombinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaCustomBinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaCustomBinderApplication.class, args);
	}

}
